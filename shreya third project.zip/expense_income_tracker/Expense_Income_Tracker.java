
package expense_income_tracker;


public class Expense_Income_Tracker {

    
    public static void main(String[] args) {
        
        new ExpensesIncomesTracker().setLocationRelativeTo(null);
        
    }

}